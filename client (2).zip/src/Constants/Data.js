export const categories=[
'Education',
'Sports',
'Movies',
'Music',
'Fashion'
];
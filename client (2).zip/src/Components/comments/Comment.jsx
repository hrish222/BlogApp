

const Comment=()=>{
    return(
        <p>Hello</p>
    )
}
export default Comment;

